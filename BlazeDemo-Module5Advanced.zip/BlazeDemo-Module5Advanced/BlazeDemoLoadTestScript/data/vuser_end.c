vuser_end()
{

	/* logout */

	web_add_cookie("XSRF-TOKEN=eyJpdiI6Iks5eE1HRGNcL2dHSTdhWjdJNDRBR2l3PT0iLCJ2YWx1ZSI6ImN5SUFNTDhrbFdqR0lueUdNZ0NUWDNLMVZmelZ4Nk1OUFNUS09nSyt3cmNNT2swbWtzaEdHYU9FaXdVREdNWFlIVVdsbTJsTW5XVFd1V2VCRnNIaERmdWE2eTV0ZEtNaWpsR2dYQ0o1QlNMOG5QVnB0dGdaWHpmdFo4QmNcL05FNCIsIm1hYyI6IjQxMTQyYzZjYzliY2MzMmFlZWY0Nzg1YTJiZDMwMmRjZDM0ZWY2YzQ0MmY4NDA0ZDMwZjlmZTNhYzIyMGU0ZDYifQ%3D%3D; DOMAIN=blazedemo.com");

	web_add_cookie("laravel_session=eyJpdiI6IlJ3RXMzeFh5MnM0bzdVZ0p1UFlZUXc9PSIsInZhbHVlIjoiajV0bDQ1M3lXRDFNZDdhWWJJRlNPVjdoWDBySHpaa2VJcXV2OVpsNjdaK0ZsXC82VGt5VWRha2wzTkxQVitcL3h0NGNiRjVvVzRBbnVoUjFVSUhVZkd4Y3RsWUYwcFZDMDRKRTBEdE9MMmQ0cjBcLzU3MGJ3WldUeWI3N0tiOVwvSEl6IiwibWFjIjoiOGZjZDQyMzEwYzk3NDkzNTZkNjY4ZTYyZTU0ZWI2MDAwYzVjMzVmZjU4MDkxMTYxMWIwODJjMzc2OGU3MTNhOSJ9; DOMAIN=blazedemo.com");

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.5");

	web_submit_data("logout", 
		"Action=https://blazedemo.com/logout", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://blazedemo.com/home", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_token", "Value=9Q9iviqB1bbU9624V73BrQhRKUioOAJYkvlPQx02", ENDITEM, 
		LAST);

	web_custom_request("pageviews_2", 
		"URL=https://blazemeter.datapipe.prodperfect.com/v1/3.0/projects/lXviifSA1NskA4wsG9N6WoWg/events/pageviews?api_key=8RWMCGFX4X0IRY1GHWDM3HM5WDSJF9LP62BSDULOL3XK7WAIFGDB7EU526O1A0UPLH1S8SJP320LUXJKCHLJX1822GU1KFE80CNW6PXVZ83IOO6LJ731EN164IFVUFMC8DOGYP2MXHN47WGVB192F2PTQRQXCF95OJWAKGOH9S69DZAI5OPJW8QSPDE6LQQ9", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://blazedemo.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"visitor\":{\"user_id\":null},\"event_uuid\":\"c2cd6e38-2cef-413e-88f1-d2f31525fe32\",\"iso_time_full\":\"2024-02-25T15:52:26.495Z\",\"local_time_full\":\"Sun Feb 25 2024 21:22:26 GMT+0530 (India Standard Time)\",\"session\":{\"session_uuid\":\"1108ffc2-12e6-450c-8738-197ef0ea6415\"},\"tracked_by\":\"prodperfect-keen-tracking-2.0.23\",\"tracker_load_uuid\":\"fa9d24f4-5ca2-4b37-a5ce-8b72d62417b8\",\"tracker_loaded_at\":\"2024-02-25T15:52:26.493Z\",\"prodperfect_test_data\":null,\"user\":{\""
		"uuid\":\"ad97b876-95ab-4769-aeef-39f6372738de\"},\"page\":{\"title\":\"BlazeDemo\",\"description\":\"BlazeMeter demo app\",\"scroll_state\":{\"pixel\":595,\"pixel_max\":595,\"ratio\":1,\"ratio_max\":1},\"time_on_page\":0,\"time_on_page_ms\":2},\"ip_address\":\"${keen.ip}\",\"geo\":{},\"user_agent\":\"${keen.user_agent}\",\"tech\":{\"profile\":{\"cookies\":true,\"codeName\":\"Mozilla\",\"description\":\"BlazeMeter demo app\",\"language\":\"en-GB\",\"name\":\"Netscape\",\"online\":true,\"platform\""
		":\"Win32\",\"useragent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0\",\"version\":\"5.0 (Windows)\",\"screen\":{\"height\":720,\"width\":1280,\"colorDepth\":24,\"pixelDepth\":24,\"availHeight\":680,\"availWidth\":1280,\"orientation\":{\"angle\":0,\"type\":\"landscape\"}},\"window\":{\"height\":595,\"width\":1280,\"scrollHeight\":595,\"ratio\":{\"height\":0.88,\"width\":1}}}},\"url\":{\"full\":\"https://blazedemo.com/\",\"info\":{}},\"referrer\":{\"initial\""
		":\"https://blazedemo.com/home\",\"full\":\"https://blazedemo.com/home\",\"info\":{}},\"time\":{\"local\":{},\"utc\":{}},\"keen\":{\"timestamp\":\"2024-02-25T15:52:26.495Z\",\"addons\":[{\"name\":\"keen:ua_parser\",\"input\":{\"ua_string\":\"user_agent\"},\"output\":\"tech\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"url.full\"},\"output\":\"url.info\"},{\"name\":\"keen:url_parser\",\"input\":{\"url\":\"referrer.full\"},\"output\":\"referrer.info\"},{\"name\":\"keen:date_time_parser\",\""
		"input\":{\"date_time\":\"keen.timestamp\"},\"output\":\"time.utc\"},{\"name\":\"keen:date_time_parser\",\"input\":{\"date_time\":\"local_time_full\"},\"output\":\"time.local\"},{\"name\":\"keen:ip_to_geo\",\"input\":{\"ip\":\"ip_address\",\"remove_ip_property\":false},\"output\":\"geo\"}]}}", 
		LAST);

	return 0;
}